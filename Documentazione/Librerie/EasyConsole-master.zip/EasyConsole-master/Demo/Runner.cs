﻿namespace Demo
{
    class Runner
    {
        static void Main(string[] args)
        {
            new DemoProgram().Run();
        }
    }
}
